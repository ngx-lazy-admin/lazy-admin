import { Component } from '@angular/core';

@Component({
  selector: 'nz-demo-spin-basic',
  template: ` <nz-spin nzSimple></nz-spin> `
})
export class NzDemoSpinBasicComponent {}
