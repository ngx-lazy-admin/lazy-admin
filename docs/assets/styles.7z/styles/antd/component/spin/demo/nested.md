---
order: 3
title:
  zh-CN: 卡片加载中
  en-US: Embedded mode
---

## zh-CN

可以直接把内容内嵌到 `nz-spin` 中，将现有容器变为加载状态。

## en-US

Embedding content into `nz-spin` will alter it into loading state.

