---
order: 2
title: 
  zh-CN: 容器
  en-US: Inside a container
---

## zh-CN

放入一个容器中。

## en-US

Spin in a container.

