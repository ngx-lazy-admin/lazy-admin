import { Component } from '@angular/core';

@Component({
  selector: 'nz-demo-radio-basic',
  template: ` <label nz-radio ngModel>Radio</label> `
})
export class NzDemoRadioBasicComponent {}
