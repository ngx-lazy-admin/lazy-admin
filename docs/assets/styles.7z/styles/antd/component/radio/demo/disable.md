---
order: 1
title:
  zh-CN: 不可用
  en-US: Disabled
---

## zh-CN

`nz-radio` 不可用。

## en-US

`nz-radio` unavailable.
