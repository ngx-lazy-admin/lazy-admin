---
order: 1
title:
  zh-CN: 单选组合
  en-US: Radio Group
---

## zh-CN

一组互斥的 `nz-radio` 配合使用。

## en-US

A group of `nz-radio` components.


