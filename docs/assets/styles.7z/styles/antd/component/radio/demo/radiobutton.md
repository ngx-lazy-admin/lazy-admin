---
order: 3
title:
  zh-CN: 按钮样式
  en-US: Radio Style
---

## zh-CN

按钮样式的单选组合。

## en-US

The combination of radio button style.


