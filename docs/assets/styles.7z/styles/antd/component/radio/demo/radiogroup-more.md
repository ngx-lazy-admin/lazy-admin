---
order: 2
title:
  zh-CN: RadioGroup 垂直
  en-US: Vertical RadioGroup
---

## zh-CN

垂直的 `nz-radio-group`，配合更多输入框选项。

## en-US

Vertical `nz-radio-group`, with more radios.

